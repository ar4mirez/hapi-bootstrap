#!/bin/sh
set -e
npm link babel-core
