var React = require('react');

var Component = React.createClass({
  render: function() {
    return (
      <head>
        <script src='//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js' />
      </head>
    );
  }
});

module.exports = Component;
