# Release Notes

## Development

[Commits](https://github.com/kpdecker/ALCE/compare/v1.2.0...master)

## v1.2.0 - December 12th, 2015
- [#1](https://github.com/kpdecker/ALCE/pull/1) - handle unary expressions ([@lukekarrys](https://api.github.com/users/lukekarrys))

[Commits](https://github.com/kpdecker/ALCE/compare/v1.1.1...v1.2.0)

## v1.1.1 - December 12th, 2015
- Update to point to new maintained repo - fe05f3e
- Add license to package.json - 5d01993

[Commits](https://github.com/walmartlabs/ALCE/compare/v1.1.0...v1.1.1)

## v1.1.0 - October 29th, 2014
- [#2](https://github.com/walmartlabs/ALCE/pull/2) - Adding support for removing keys from a collection ([@jherr](https://api.github.com/users/jherr))

[Commits](https://github.com/walmartlabs/ALCE/compare/v1.0.1...v1.1.0)

## v1.0.1 - November 6th, 2013

- Add repository field to package.json - 413124c
- Fix import issue - 2ee031c

[Commits](https://github.com/walmartlabs/ALCE/compare/v1.0.0...v1.0.1)

## v1.0.0 - September 7th, 2013

- Initial release

[Commits](https://github.com/walmartlabs/ALCE/compare/7569ab4...v1.0.0)
