#nigel

Boyer-Moore-Horspool algorithms.

[![Build Status](https://secure.travis-ci.org/hapijs/nigel.svg)](http://travis-ci.org/hapijs/nigel)

Lead Maintainer - [Eran Hammer](https://github.com/hueniverse)
