'use strict';

exports = module.exports = 'not a function';
