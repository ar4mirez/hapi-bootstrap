# Release Notes

## Development

[Commits](https://github.com/walmartlabs/ALCE/compare/v1.0.0...master)

## v1.0.0 - September 7th, 2013

- Initial release

[Commits](https://github.com/walmartlabs/ALCE/compare/7569ab4...v1.0.0)
