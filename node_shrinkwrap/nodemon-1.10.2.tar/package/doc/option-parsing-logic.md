# Option parsing logic

1. Read all CLI arguments
2. Load local config
3. Load global config
4. Try backup: package.main
5. Try backup: package.start
6. Try index.js
