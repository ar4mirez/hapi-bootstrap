var React = require('react');

var Component = React.createClass({
  render: function() {
    return (
      <div id="footer">
        <p>hapi.js 203</p>
      </div>
    );
  }
});

module.exports = Component;
