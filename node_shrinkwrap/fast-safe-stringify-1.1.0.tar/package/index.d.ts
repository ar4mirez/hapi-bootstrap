declare function stringify(data: any): string;

export = stringify;