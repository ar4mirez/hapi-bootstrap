#call

HTTP Router.

[![Build Status](https://secure.travis-ci.org/hapijs/call.png)](http://travis-ci.org/hapijs/call)

Lead Maintainer - [Eran Hammer](https://github.com/hueniverse)
