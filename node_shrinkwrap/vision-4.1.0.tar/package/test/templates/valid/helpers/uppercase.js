'use strict';

exports = module.exports = function (context) {

    return context.toUpperCase();
};
