'use strict';

exports.y = 2;
