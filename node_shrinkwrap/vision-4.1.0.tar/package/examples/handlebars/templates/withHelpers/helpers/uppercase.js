'use strict';

module.exports = function (message) {

    return message.toString().toUpperCase();
};
