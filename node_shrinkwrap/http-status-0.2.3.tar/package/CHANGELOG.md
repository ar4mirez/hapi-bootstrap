# Changelog: HTTP Status

## Version 0.1.1 – Nov 13, 2012

-   Module as a better citizen
-   Makefile to compile and run tests

## Version 0.1.1 – Dec 13, 2011

-   Code officially under the BSD License

## Version 0.1.0 – April 17, 2011

-   Added reference links to HTTP specification
-   Fixed naming convention for constants from `PascalCase` to `ALL_CAPS`
-   Converted status codes from string to number
-   Updated samples
-   Updated tests
-   Added this `CHANGELOG`

## Version 0.0.1 – March 25, 2011

-   Initial release.
