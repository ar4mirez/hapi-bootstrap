# Swagger Specification JSON Schemas

This is only JSON Schema file for Swagger version 2.0. Download and Install it via NPM or Bower.

## Install via NPM

```shell
npm install --save swagger-schema-official
```

#### Install 1.2 version via NPM

```shell
npm install --save swagger-schema-official@1.2.0
```
## Install via Bower

 ```shell
 bower install --save swagger-schema
 ```

## License

 MIT
